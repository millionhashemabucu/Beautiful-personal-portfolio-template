$(document).ready(function(){
    $(window).scroll(function(){
        if(this.scrollY > 20){
            $('.navbar').addClass('sticky')
        }
        else{
            $('.navbar').removeClass('sticky')
        }
        // top to bottom 
        if(this.scrollY > 500){
            $('.top').addClass('bottom')
        }
        else{
            $('.top').removeClass('bottom')
        }
    })
    $('.top').click(function(){
        $('html').animate({
            scrollTop:0,
        })
    })
    // end top to bottom

    // typed script for team 
    var typeid = new Typed(" .typing",{
        strings: ["Designer",'Developer',"photographer"],
        typeSpeed: 100,
        backSpeed:60,
        loop:true
    })
        // typed script for about 
        var typeid = new Typed(" .typing-2",{
            strings: ["Designer",'Developer',"photographer"],
            typeSpeed: 100,
            backSpeed:60,
            loop:true
        })
    // show mobile menu 
    $('.menu-btn').click(function(){
        $('.navbar .menu').toggleClass('active')
        $('.menu-btn i').toggleClass('active')
    })

    // owl carousel script
    $('.carousel').owlCarousel({
            loop:true,
        margin:10,
        autoplay:true,
        autoplayTimeout:3000,
        autoplayHoverPause:true,
        responsive: {
            0:{
                items : 1,
                nav : true
            },
            600:{
                items:2,
            },
            1000:{
                items:3,
                nav:false
            }
        }

    })
})